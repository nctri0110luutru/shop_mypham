<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class introduce extends Model
{
    protected $table="introduce";
    public $timestamps = false;
}
