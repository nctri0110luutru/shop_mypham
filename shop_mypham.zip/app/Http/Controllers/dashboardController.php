<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
class dashboardController extends Controller
{
	public function getdashboard()
	{
		$sp_hethang=DB::table("product")->where("quantity",0)->get();
		$customer=DB::table("customer")->get();

		$tongsp=0;
		$tongsosp=DB::table("product")->select("quantity")->get();
		foreach ($tongsosp as $value) {
			$tongsp+=$value->quantity;
		}
		// echo $tongsp;

		$re=DB::table("review")->get();
		$email=DB::table("email_registed")->get();
		$member=DB::table("users")->where("privilege",0)->get();
		$admin=DB::table("users")->where("privilege",1)->get();
		
		return view('admin.dashboard',compact("sp_hethang","customer","tongsp","re","email","member","admin"));
	}
}
