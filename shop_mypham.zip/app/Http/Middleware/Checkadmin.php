<?php

namespace App\Http\Middleware;

use Closure;
use Auth;

class Checkadmin
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        if(Auth::check()){
            if (Auth::user()->privilege === 1) {
                return $next($request);//nêu đúng cho chuyen trang
            }
            else{
                return redirect('/login'); //k dung thi về lại trang chủ của khách hàng
            }
        }
        else{
            return redirect('/login');
        }        
    }
}
