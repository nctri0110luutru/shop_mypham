<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
class pageConttroller extends Controller
{
    public function getHome()
    {
    	$sp_noi_bat=DB::select("CALL sp_select_all_product()");
    	$sp_last= DB::table('product')->orderBy("id","desc")->first();
    	// dd($sp_last);
    	$sp_sale=DB::table('product')->where("promotion_price","<>",0)->orderBy("id","desc")->take(16)->get();
    	$sp_gia_re=DB::table('product')->where("unit_price","<=",300000)->orderBy("id","desc")->take(12)->get();
    	return view('client.home',compact("sp_noi_bat","sp_last","sp_sale","sp_gia_re"));
    }
}
