<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Cart,DB;
use App\customer;
use App\bill;
use App\bill_detail;
class cartCotroller extends Controller
{
    public function getShoppingCart($id)
    {
    	$pro=DB::table('product')->where('id',$id)->first(); 
    	$price=0;	
    	if($pro->promotion_price==0){
	    	$price=$pro->unit_price;
     	}
     	else{
     		$price=$pro->promotion_price;
     	}
     	Cart::add([
	    		['id' => $id, 'name' => $pro->name, 'quantity' => 1, 'price' => $price, 'attributes' => array('image' => $pro->image,'productquantity'=>$pro->quantity)]
	    	]);
	    // Cart::getContent();
	    return redirect()->route("getCart");
    }
    public function postShoppingCart(Request $re)
    {
    	// $productquantity=DB::table("product")->select("quantity")->get();
    	// 	if($re->qty>$productquantity)
    	// 	{
    	// 		return redirect()->back()->width("hethang");
    	// 	}
    	// dd($re->all());
    	$pro=DB::table('product')->where('id',$re->id)->first(); 	
    	$price=0;	
    	if($pro->promotion_price==0){
	    	$price=$pro->unit_price;
     	}
     	else{
     		$price=$pro->promotion_price;
     	}
    	Cart::add([
    		['id' => $re->id, 'name' => $pro->name, 'quantity' => $re->qty, 'price' => $price, 'attributes' => array('image' => $pro->image,'productquantity'=>$pro->quantity)]
    	]);
    	// echo Cart::getContent();
    	return redirect()->route("getCart");
    }

    public function getCart()
    {
    	return view("client.cart");
    }

    //post update cart
    public function updateCart(Request $re)
    {
    	$array=$re->all();
    	foreach($array as $k=>$v){
			if($k!="_token"){
				Cart::update($k, array(
				  'quantity' => array(
				      'relative' => false,
				      'value' => $v
				  ),
				));

			}
    	}
    	return redirect()->back()->with("updatecartsuccess");
    }
    //remove one cart
    public function remove_one_Cart(Request $re)
    {
    	if($re->ajax()){
    		Cart::remove($re->id);
    		return "ok";
    	}
    	else{
    		return "no";
    	}
    }
    // remove_all_Cart
    public function remove_all_Cart(Request $re)
    {
    	if($re->ajax()){
    		Cart::clear();
    		return "ok";
    	}
    	else{
    		return "no";
    	}
    }
    // check out
    public function getCheckOut()
    {
    	return view("client.checkout");
    }
    //post check out
    public function postCheckOut(Request $re)
    {
    	$re->validate([
		    'name' => 'required',
		    'gender' => 'required|min:2|max:4',
		    'email' => 'required|email',
		    'address' => 'required|max:255',
		    'phone' => 'required|numeric|regex:/(0)[0-9]{9}/',
		],[
            'name.required' => 'Bạn chưa nhập tên!',
            'gender.required' => 'chưa nhập giới tính!',
            'gender.min' => 'Nhập giới tính là nữ or nam!',
            'gender.max' => 'Nhập giới tính là nữ or nam!',
            'address.required' => 'Bạn chưa nhập địa chỉ!',
            'address.max' => 'Địa chỉ bạn nhập quá dài!',
            'phone.required' => 'chưa nhập giới tính!',
            'phone.numeric' => 'Bạn phải nhập số!',
            'phone.regex' => 'Số điện thoại chưa đúng định dạng!',

        ]);
        

        $cus=new customer();
        $cus->name=$re->name;
        $cus->gender=$re->gender;
        $cus->email=$re->email;
        $cus->address=$re->address;
        $cus->phone=$re->phone;
        $cus->phone=$re->phone;
        $cus->note=$re->note;
        $cus->save();

        $id_cus=$cus->id;
        // echo $id_cus;

        $b=new bill();
        $b->customer_ID=$id_cus;
        $b->total=Cart::getSubTotal();
        $b->payment=$re->payments;
        $b->save();

        $id_bill=$b->id;

        
        
        foreach (Cart::getContent() as $value) {
            $bdt=new bill_detail();
            $bdt->bill_ID=$id_bill;
            $bdt->product_ID=$value->id;
            $bdt->quantity=$value->quantity;
            $bdt->unit_price=$value->price;
            $bdt->save();
        }
        Cart::clear();
        return redirect('/')->with('checkout_success', 'dat hang thanh cong!');
         // return redirect()->back()->with('checkout_success', "dat hang thanh cong");   
        




    	// dd($re->all());
    }

}
