<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\policy;
class policyController extends Controller
{
    public function getpolicy()
    {
    	$policy=DB::table("policy")->orderBy("id","desc")->get();
    	return view("admin.policy",compact("policy","id"));
    }

    public function postpolicy(Request $re)
    {
    	// dd($re->all());
    	$re->validate([
		    'add_policy' => 'required'
		],[
			'add_policy.required' => 'Bạn chưa nhập thông tin!'
		]);

    	if($re->add_policy){
    		$r=new policy();
    		$r->policy_detail=$re->add_policy;
    		$r->save();
    		return redirect()->route("getpolicy")->with(["message"=>"Thêm thành công","warning"=>"success"]);
    	}
    	else{
    		return redirect()->route("getpolicy")->with(["message"=>"Đã xảy ra lỗi!","warning"=>"danger"]);
    	}

    }

	public function delete_policy($id)
	{
	    if($id){
	    	$del=policy::find($id);
	    	$del->delete();
	    	return redirect()->route("getpolicy")->with(["message"=>"Xóa thành công","warning"=>"success"]);
	    }
	    else{
	    	return redirect()->route("getpolicy")->with(["message"=>"Đã xảy ra lỗi!","warning"=>"danger"]);
	    }
	}

	//edit
	public function posteditpolicy(Request $re)
    {
    	// dd($re->all());
    	$re->validate([
		    'edit_id_recruitment' => 'required',
		    'edit_policy_detail' => 'required',
		],[
			'edit_id_recruitment.required' => 'Bạn chưa nhập thông tin!',
			'edit_policy_detail.required' => 'Bạn chưa nhập thông tin!'
		]);
    	$edit_rec=policy::find($re->edit_id_recruitment);
    	if($edit_rec){
    		$edit_rec->policy_detail=$re->edit_policy_detail;
    		$edit_rec->save();
    		return redirect()->route("getpolicy")->with(["message"=>"Sửa thành công","warning"=>"success"]);
    	}
    	else{
    		return redirect()->route("getpolicy")->with(["message"=>"Đã xảy ra lỗi!","warning"=>"danger"]);
    	}

    }
}
