<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
class infoController extends Controller
{
    public function getintroduce()
    {
    	$in=DB::table('introduce')->orderBy('id','desc')->first();
    	return view('client.introduce',compact("in"));
    }
    public function getrecruitment()
    {
    	$rec=DB::table('recruitment')->orderBy('id','desc')->first();
    	return view('client.recruitment',compact("rec"));
    }
    public function getpolicy()
    {
    	$po=DB::table('policy')->orderBy('id','desc')->first();
    	return view('client.policy',compact("po"));
    }
}
