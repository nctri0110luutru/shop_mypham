<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class reviewModel extends Model
{
   	protected $table = "review";
   	public $timestamps = true;

}
