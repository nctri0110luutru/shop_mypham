<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class recruitment extends Model
{
     protected $table = "recruitment";
   	public $timestamps = false;
}
