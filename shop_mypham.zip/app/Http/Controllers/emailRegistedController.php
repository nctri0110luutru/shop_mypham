<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\emailregisted;

class emailRegistedController extends Controller
{
    public function getEmailRegisted(Request $re)
    {
    	$re->validate([
    		'email' => 'required|email|unique:email_registed,email|max:255',
		]);
    	$email= $re->email;
    	$import= new emailregisted;
    	$import->email=$email;
    	$import->save();
    	return redirect()->back()->with(["alert"=>"ok"]);
    }
}
