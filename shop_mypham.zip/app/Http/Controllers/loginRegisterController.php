<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use Auth;

class loginRegisterController extends Controller
{
    //
    public function getloginclient()
    {
    	return view('client.login_register');
    }
    public function postloginclient(Request $re)
    {
        // dd(Auth::user());
    	if (Auth::attempt(['email' => $re->email, 'password' => $re->password])) {
    		return redirect()->route('getHome')->with('loginsuccess', 'Đăng nhập thành công!');
    	}
    	else{
    		return redirect()->route('getloginclient')->with('loginfail', 'Tài khoản hoặc mật khẩu không chính xác!');
    	}
    	
    }
    public function postregisterclient(Request $re)
    {
    	$validatedData = $re->validate([
	        'full_name' => 'required',
	        'email' => 'required|email|unique:users,email',
	        'phone' => 'required|max:12',
	        'address' => 'required',
	        'password' => 'required|min:6|max:32',
   		],[
   			'full_name.required' => 'Bạn phải nhập tên!',
	        'email.required' => 'Bạn phải nhập email!',
	        'email.email' => 'Email chưa đúng định dạng!',
	        'email.unique' => 'Có người khác đã sử dụng email này!',
	        'phone.required' => 'Bạn phải nhập SĐT!',
	        'address.required' => 'Bạn phải nhập địa chỉ!',
	        'password.required' => 'Bạn phải nhập password!',
	        'password.min' => 'password phải >= 6 kí tự!',
	        'password.max' => 'password phải <= 32 kí tự!',
   		]);
    	$u= new User();
    	$u->full_name=$re->full_name;
    	$u->email=$re->email;
    	$u->phone=$re->phone;
    	$u->address=$re->address;
    	$u->password=bcrypt($re->password);
    	$u->privilege=0;
    	$u->save();
    	// dd($re->all());
    	return redirect()->route('getloginclient')->with('registersuccess', 'Đăng kí thành công!');
    }

    public function getlogoutclient()
    {
    	Auth::logout();
    	return redirect()->route('getloginclient');
    }
}
