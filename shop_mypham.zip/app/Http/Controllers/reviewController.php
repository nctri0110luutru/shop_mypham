<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\reviewModel;
use App\product;
use DB;

class reviewController extends Controller
{
    public function getreview(Request $re)
    {
    	$review_pro= DB::table('review')
            ->join('product', 'product.id', '=', 'review.product_ID')
            ->select('review.*', 'product.name', 'product.image')
            ->get();
        return view("admin.review",compact("review_pro"));
    	
    }


    public function delete_review($id)
    {
    	if($id){
    		$re=reviewModel::find($id);
    		$re->delete();
    		return redirect()->route("getreview")->with(["message"=>"Xóa thành công","warning"=>"success"]);
    	}
    	else{
    		return redirect()->route("getreview")->with(["message"=>"Đã xảy ra lỗi","warning"=>"danger"]);
    	}
    	
    	
    }
}
