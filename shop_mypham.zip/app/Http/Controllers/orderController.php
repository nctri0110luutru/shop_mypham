<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\customer;
use App\bill;
use App\bill_detail;
class orderController extends Controller
{
	public function getorder()
	{
		$order=DB::table('customer')
            ->join('bill', 'customer.id', '=', 'bill.customer_ID')
            // ->join('bill_detail', 'bill.id', '=', 'bill_detail.bill_ID')
            // ->join('product', 'bill_detail.product_id', '=', 'product.id')
            ->select('customer.*', 'bill.id as id_bill', 'bill.total')
            ->get();

            //truyen cai id_bill r lọc ở bảng bill là dk
           // dd($order);
        return view("admin.order",compact("order"));
	}


	//delete
	 public function delete_order($id_cus,$id_bill)
	{
		echo $id_cus;
		echo $id_bill;
	    if($id_cus){
	    	$cus=customer::find($id_cus);
	    	$bill=bill::find($id_bill);
	    	$bill_detail=bill_detail::where("bill_ID",$id_bill)->get();
	    	foreach ($bill_detail as $b) {
	    		$bdt=bill_detail::find($b->id);
	    		$bdt->delete();
	    	}
	    	$bill->delete();
	    	$cus->delete();
	    	return redirect()->route("getcategory")->with(["message"=>"Xóa thành công!","warning"=>"success"]);
	    }
	    else{
	    	return redirect()->route("getcategory")->with(["message"=>"Xóa thất bại!","warning"=>"danger"]);
	    }
	}


	public function posteditorder(Request $re)
	{
		// dd($re->all());
		$re->validate([
		    'edit_name' => 'required',
		    'edit_gender' => 'required|min:2|max:4',
			'edit_address' => 'required',
		    'edit_phone' => 'required|numeric|regex:/(0)[0-9]{9}/',
		],[
			'edit_name.required' => 'Bạn chưa nhập tên Khách hàng!',
			'edit_gender.required' => 'chưa nhập giới tính!',
			'edit_gender.min' => 'Nhập giới tính là nữ or nam!',
			'edit_gender.max' => 'Nhập giới tính là nữ or nam!',
			'edit_address.required' => 'Bạn chưa nhập địa chỉ!',
			'edit_address.max' => 'Địa chỉ bạn nhập quá dài!',
			'edit_phone.required' => 'chưa nhập giới tính!',
			'edit_phone.numeric' => 'Bạn phải nhập số!',
			'edit_phone.regex' => 'Số điện thoại chưa đúng định dạng!',

		]);
		if($re->edit_id){
    		$cus=customer::find($re->edit_id);
    		$cus->name=$re->edit_name;
    		$cus->gender=$re->edit_gender;
    		$cus->address=$re->edit_address;
    		$cus->phone=$re->edit_phone;
    		$cus->save();
    		return redirect()->route("getorder")->with(["message"=>"Sửa thành công","warning"=>"success"]);
    	}
    	else{
    		return redirect()->route("getorder")->with(["message"=>"Lỗi!!Bạn chờ vài giây để trang kip load nhé!","warning"=>"danger"]);
    	}
	}

	public function print_order($id_cus,$id_bill)
	{
		$cus=DB::table('customer')->where("id",$id_cus)->first();
		$bill=DB::table('bill')->where("id",$id_bill)->first();
		$bill_detail=DB::table('bill_detail')
		->join('product', 'bill_detail.product_id', '=', 'product.id')
		->where("bill_ID",$id_bill)
		->select('bill_detail.*','product.image','product.name')
		->get();
           // dd($bill_detail);
		return view("admin.print_order",compact("cus","bill","bill_detail"));
	}
    
}
