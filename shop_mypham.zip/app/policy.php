<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class policy extends Model
{
    protected $table = "policy";
   	public $timestamps = false;
}
