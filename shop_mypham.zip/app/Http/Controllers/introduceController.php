<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\introduce;
use File;

class introduceController extends Controller
{
    public function getintroduce()
    {
    	$introduce=DB::table("introduce")->orderBy("id","desc")->get();
    	return view("admin.introduce",compact("introduce"));
    }

    public function postintroduce(Request $re)
    {
    	// dd($re->all());
 		$re->validate([
		    'add_introduce' => 'required',
		    'add_logo' =>'required',
		],[
			'add_logo.required' => 'Bạn chưa chọn file!',
			'add_introduce.required' => 'Bạn chưa nhập tin giới thiệu!'
		]);

		$file=$re->file("add_logo");
		$extension=["jpg","png","gif"];
		$flag=true;
		if($re->hasFile("add_logo")){
				$name_extension=$file->getClientOriginalExtension();
				// echo $name_extension;
				$check=in_array($name_extension, $extension);
				if(!$check){
					$flag=false;
					return redirect()->route("getintroduce")->with(["message"=>"File không đúng định dạng!","warning"=>"danger"]);
				}
		}

		if($flag){			
			if(isset($file)){
				$name_image=date("ymdhis").$file->getClientOriginalName();
				echo $name_image;
				$in=new introduce();
				$in->logo=$name_image;
				$in->introduce_detail=$re->add_introduce;
				$file->move("upload/introduce/",$name_image);
				$in->save();
			}
			return redirect()->route("getintroduce")->with(["message"=>"Thêm thành công!","warning"=>"success"]);
		}

    }

    public function delete_introduce($id)
    {
    	if($id){
   			$del=introduce::find($id);
   			if(!empty($del)){
   				$url="upload/introduce/".$del->logo;
   				if(File::exists($url)){
   					File::delete($url);
   				}
   				$del->delete();
    			return redirect()->route("getintroduce")->with(["message"=>"Xóa thành công!","warning"=>"success"]);
   			}
   		}
   		else{
   			return redirect()->route("getintroduce")->with(["message"=>"Xóa thất bại!","warning"=>"danger"]);
   		}
    }



    //edit
    public function posteditintroduce(Request $re)
    {
    	// dd($re->all());
 		$re->validate([
		    'edit_introduce_detail' => 'required',
		],[
			'edit_introduce_detail.required' => 'Bạn chưa nhập tin giới thiệu!'
		]);

		$file=$re->file("logo_new");
		$extension=["jpg","png","gif"];
		$flag=true;
		if($re->hasFile("logo_new")){
				// echo "has";
				$name_extension=$file->getClientOriginalExtension();
				// echo $name_extension;
				$check=in_array($name_extension, $extension);
				if(!$check){
					$flag=false;
					return redirect()->route("getintroduce")->with(["message"=>"File không đúng định dạng!","warning"=>"danger"]);
				}
		}

		if($flag){			
			if(isset($file)){
				$name_image=date("ymdhis").$file->getClientOriginalName();
				// echo $name_image;
				$in=introduce::find($re->edit_id_introduce);
				$in->logo=$name_image;
				$in->introduce_detail=$re->edit_introduce_detail;
				$file->move("upload/introduce/",$name_image);
				$url_old="upload/introduce/".$re->logo_old;
				// echo $url_old;
				if(File::exists($url_old)){
					if(File::delete($url_old));
				}
				$in->save();
				return redirect()->route("getintroduce")->with(["message"=>"Sửa thành công!","warning"=>"success"]);
			}
			else{
				$in=introduce::find($re->edit_id_introduce);
				$in->introduce_detail=$re->edit_introduce_detail;
				$in->save();
				return redirect()->route("getintroduce")->with(["message"=>"Sửa thành công!","warning"=>"success"]);
			}
			
		}

    }
}
