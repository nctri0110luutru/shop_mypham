-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 13, 2019 at 04:25 AM
-- Server version: 10.1.34-MariaDB
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mypham`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `showSlide` ()  BEGIN
   SELECT * FROM slide;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_select_all_category` ()  BEGIN
   select * FROM category WHERE parent_ID=0;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_select_all_product` ()  BEGIN
   SELECT * FROM product ORDER BY id DESC;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `bill`
--

CREATE TABLE `bill` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `customer_ID` bigint(20) UNSIGNED NOT NULL,
  `total` double(8,2) NOT NULL,
  `payment` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `bill`
--

INSERT INTO `bill` (`id`, `customer_ID`, `total`, `payment`, `created_at`, `updated_at`) VALUES
(7, 12, 700000.00, 'COD', '2019-03-09 09:05:39', '2019-03-09 09:05:39');

-- --------------------------------------------------------

--
-- Table structure for table `bill_detail`
--

CREATE TABLE `bill_detail` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `bill_ID` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `quantity` int(11) NOT NULL,
  `unit_price` double(8,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `bill_detail`
--

INSERT INTO `bill_detail` (`id`, `bill_ID`, `product_id`, `quantity`, `unit_price`, `created_at`, `updated_at`) VALUES
(7, 7, 2, 1, 250000.00, '2019-03-09 09:05:39', '2019-03-09 09:05:39'),
(8, 7, 3, 3, 150000.00, '2019-03-09 09:05:39', '2019-03-09 09:05:39');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_ID` bigint(20) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `name`, `description`, `parent_ID`, `created_at`, `updated_at`) VALUES
(1, 'sữa rữa mặt', 'sưa rua măt giúp làn da luon khoe manh', 0, NULL, NULL),
(2, 'phấn da', 'Phấn giúp làn da bạn trở nên trắng mịn', 0, NULL, NULL),
(3, 'sưa rưa măt danh cho nam', 'sưa rưa măt danh cho nam giup ngăn ngừa mụn', 1, NULL, NULL),
(4, 'sưa rua mat nu', 'sua rua mat nu giup lan da phu nu giam mun', 1, NULL, NULL),
(5, 'son moi', 'son môi giup phu nu ảo kinh', 0, NULL, NULL),
(6, 'son moi 3CE', 'son môi giup phu nu ảo kinh khủng', 5, NULL, NULL),
(7, 'son bóng', 'son môi giup phu nu ảo kinh khủng', 5, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gender` varchar(4) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(11) COLLATE utf8mb4_unicode_ci NOT NULL,
  `note` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`id`, `name`, `gender`, `email`, `address`, `phone`, `note`, `created_at`, `updated_at`) VALUES
(12, 'nguyen cao tri', 'nam', 'nguyenthihuong150998@gmail.com', 'đong khoi, dsd, xuan bac', '334675630', NULL, '2019-03-09 09:05:39', '2019-03-09 09:05:39');

-- --------------------------------------------------------

--
-- Table structure for table `email_registed`
--

CREATE TABLE `email_registed` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `email` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `email_registed`
--

INSERT INTO `email_registed` (`id`, `email`, `created_at`, `updated_at`) VALUES
(1, 'nguyenthihuong150998@gmail.com', '2019-01-21 21:02:46', '2019-01-21 21:02:46'),
(2, 'nctri0110@gmail.com', '2019-01-21 21:05:28', '2019-01-21 21:05:28'),
(3, 'nguyenthihuo^^^ng15998@gmail.com', '2019-01-21 21:05:59', '2019-01-21 21:05:59'),
(4, 'dddddđ', '2019-01-21 21:43:00', '2019-01-21 21:43:00'),
(5, 'cobelangcam0605@yahoo.com', '2019-01-21 21:47:52', '2019-01-21 21:47:52');

-- --------------------------------------------------------

--
-- Table structure for table `introduce`
--

CREATE TABLE `introduce` (
  `id` int(10) UNSIGNED NOT NULL,
  `introduce_detail` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `logo` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `introduce`
--

INSERT INTO `introduce` (`id`, `introduce_detail`, `logo`, `created_at`) VALUES
(1, '<h1>Về chúng tôi!</h1>\r\n<p>dfgsdfg dfgsdfg sdfg dfgsd fgdfg dfg dfg dsfg dsfg dfg dfgd fg sdfg fdg dfg fg dsfg sdfg sdfg sdfg sdfg sdfg df sdfg dfg dfg dfs gdfg df gdfg df gsdfg  fgdsfg dfgsdfg dsfg sdfg sdfg sdfg dfg dfg sd fgsdfg sdf gsdfg sdfg sdfg sdf gdf gsdfgsd dfgsdf dfsg sdfg sdf gsdf gs dfg dsfg sd fg sdfg sd fg sdf g dsfg sd fg dsf gs dfg sdf gsd gds fg sdf gsd fg dfsgds g sdfd gds gsd fg dsfg sdf gdfsg df gdf fd</p>\r\n<p>sfrerwrwsf dfgsdfgew ưertewr wer tewrt ẻ twert wer tewrt we rtwer tewt ewrt erwt erw terwt e rt erwt ert ẻ te rt ert ert ret</p>\r\n\r\n', 'default1.jpg', '2019-03-13 02:14:25');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(25, '2014_10_12_000000_create_users_table', 1),
(26, '2014_10_12_100000_create_password_resets_table', 1),
(27, '2019_01_19_064959_create_slide_table', 1),
(28, '2019_01_19_065247_create_category_table', 1),
(29, '2019_01_19_065328_create_product_table', 1),
(30, '2019_01_19_065357_create_product_image_table', 1),
(31, '2019_01_19_065422_create_review_table', 1),
(32, '2019_01_19_065457_create_bill_table', 1),
(33, '2019_01_19_065521_create_customer_table', 1),
(34, '2019_01_19_065600_create_bill_detail_table', 1),
(35, '2019_01_22_031551_create_email_registed_table', 2);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `policy`
--

CREATE TABLE `policy` (
  `id` int(10) UNSIGNED NOT NULL,
  `policy_detail` longtext COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `policy`
--

INSERT INTO `policy` (`id`, `policy_detail`) VALUES
(1, '<h1>Chính sách đổi trả</h1>\r\n<p>dfgsdfg dfgsdfg sdfg dfgsd fgdfg dfg dfg dsfg dsfg dfg dfgd fg sdfg fdg dfg fg dsfg sdfg sdfg sdfg sdfg sdfg df sdfg dfg dfg dfs gdfg df gdfg df gsdfg fgdsfg dfgsdfg dsfg sdfg sdfg sdfg dfg dfg sd fgsdfg sdf gsdfg sdfg sdfg sdf gdf gsdfgsd dfgsdf dfsg sdfg sdf gsdf gs dfg dsfg sd fg sdfg sd fg sdf g dsfg sd fg dsf gs dfg sdf gsd gds fg sdf gsd fg dfsgds g sdfd gds gsd fg dsfg sdf gdfsg df gdf fd</p>\r\n\r\n<p>sfrerwrwsf dfgsdfgew ưertewr wer tewrt ẻ twert wer tewrt we rtwer tewt ewrt erwt erw terwt e rt erwt ert ẻ te rt ert ert ret</p>');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `detail` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `brand` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `unit_price` double(8,2) NOT NULL,
  `promotion_price` double(8,2) NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` int(11) NOT NULL,
  `category_ID` bigint(20) UNSIGNED NOT NULL,
  `review_ID` bigint(20) UNSIGNED NOT NULL,
  `gender_use` int(11) NOT NULL COMMENT '0:nu 1:nam',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `name`, `description`, `detail`, `brand`, `unit_price`, `promotion_price`, `image`, `quantity`, `category_ID`, `review_ID`, `gender_use`, `created_at`, `updated_at`) VALUES
(1, 'son môi 3CE', 'son môi giúp bạn nổi bật hơn', 'bạn sẻ ấn tượng với những mẫu son mới của chúng tôi... bờ môi của bạn sẻ trở nên quyến rũ hơn bao giờ hết', '3CE', 300000.00, 125000.00, 'default4.jpg', 0, 6, 0, 0, NULL, NULL),
(2, 'son môi bong', 'son môi giúp bạn nổi bật hơn', 'bạn sẻ ấn tượng với những mẫu son mới của chúng tôi... bờ môi của bạn sẻ trở nên quyến rũ hơn bao giờ hết', '', 300000.00, 250000.00, 'default1.jpg', 60, 7, 0, 0, NULL, NULL),
(3, 'son môi bong1', 'son môi giúp bạn nổi bật hơn', 'bạn sẻ ấn tượng với những mẫu son mới của chúng tôi... bờ môi của bạn sẻ trở nên quyến rũ hơn bao giờ hết', '', 150000.00, 0.00, 'default3.jpg', 60, 7, 0, 0, NULL, NULL),
(4, 'son môi bong222', 'son môi giúp bạn nổi bật hơn', 'bạn sẻ ấn tượng với những mẫu son mới của chúng tôi... bờ môi của bạn sẻ trở nên quyến rũ hơn bao giờ hết', '', 150000.00, 0.00, 'default6.jpg', 60, 7, 0, 0, NULL, NULL),
(5, 'phan mat', 'phan giup doi mat dep', 'phan giup doi mat phu nu dep tro nen dep hon', '', 300000.00, 260000.00, 'product1.jpg', 4, 2, 0, 0, NULL, NULL),
(6, 'phan ma hong', 'phan giup doi má bạn hông hao', 'phan giup doi má bạn hông hao quyen ru hon', '', 300000.00, 285000.00, 'product2.jpg', 5, 2, 0, 0, NULL, NULL),
(7, 'phan toan than', 'phan giup toan than trang minn hông hao', 'phan giup toan than bạn trang va quyen ru hon', '', 300000.00, 188000.00, 'product3.jpg', 5, 2, 0, 0, NULL, NULL),
(8, 'son 4ee', 'son giup doi moi hong hao quyen ru', 'son giup doi moi hong hao quyen ru kinh hồn', '', 400000.00, 340000.00, 'product3.jpg', 5, 5, 0, 0, NULL, NULL),
(9, 'son 5kk', 'son giup doi moi hong hao quyen ru', 'son giup doi moi hong hao quyen ru kinh hồn', '', 700000.00, 560000.00, 'default5.jpg', 5, 5, 0, 0, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `product_image`
--

CREATE TABLE `product_image` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_ID` bigint(20) UNSIGNED NOT NULL,
  `color` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `recruitment`
--

CREATE TABLE `recruitment` (
  `id` int(10) UNSIGNED NOT NULL,
  `recruitment_detail` longtext COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `recruitment`
--

INSERT INTO `recruitment` (`id`, `recruitment_detail`) VALUES
(1, '<h1>Thông tin tuyển dụng</h1>\r\n<p>dfgsdfg dfgsdfg sdfg dfgsd fgdfg dfg dfg dsfg dsfg dfg dfgd fg sdfg fdg dfg fg dsfg sdfg sdfg sdfg sdfg sdfg df sdfg dfg dfg dfs gdfg df gdfg df gsdfg fgdsfg dfgsdfg dsfg sdfg sdfg sdfg dfg dfg sd fgsdfg sdf gsdfg sdfg sdfg sdf gdf gsdfgsd dfgsdf dfsg sdfg sdf gsdf gs dfg dsfg sd fg sdfg sd fg sdf g dsfg sd fg dsf gs dfg sdf gsd gds fg sdf gsd fg dfsgds g sdfd gds gsd fg dsfg sdf gdfsg df gdf fd</p>\r\n\r\n<p>sfrerwrwsf dfgsdfgew ưertewr wer tewrt ẻ twert wer tewrt we rtwer tewt ewrt erwt erw terwt e rt erwt ert ẻ te rt ert ert ret</p>');

-- --------------------------------------------------------

--
-- Table structure for table `review`
--

CREATE TABLE `review` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `customer_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_email` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_ID` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `review`
--

INSERT INTO `review` (`id`, `customer_name`, `customer_email`, `message`, `product_ID`, `created_at`, `updated_at`) VALUES
(1, 'tri', 'nctri0110@gmail.com', 'sp cua shop rât chất lượng...mong shop nhập thêm nhiều mẫu mới để moi nguoi co thể lua chọn thỏa thích', 1, '2019-02-17 19:19:46', '2019-02-17 19:19:46'),
(2, 'huong', 'nguyenthihuong@gmail.com', 'sp cua shop rât chất lượng...mong shop nhập thêm nhiều mẫu mới để moi nguoi co thể lua chọn thỏa thích', 1, '2019-02-17 19:19:46', '2019-02-17 19:19:46'),
(3, 'nguyen cao tri', 'nctri0110@gmail.com', 'mmmmmmmmmmmmmmmkkkkkkkkkkk', 9, '2019-02-27 20:37:20', '2019-02-27 20:37:20'),
(4, 'tri', 'nctri0110php@gmail.com', 'shop này quá chất!!', 9, '2019-02-27 20:42:40', '2019-02-27 20:42:40'),
(5, 'nguyen cao tri', 'nctri01102@gmail.com', 'iiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii', 9, '2019-02-27 20:51:48', '2019-02-27 20:51:48'),
(6, 'nguyen cao tri', 'nctri0110php@gmail.com', 'kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk', 9, '2019-02-27 20:52:09', '2019-02-27 20:52:09'),
(7, 'nguyen cao tri', 'nctri01102@gmail.com', 'bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb', 9, '2019-02-27 20:58:34', '2019-02-27 20:58:34'),
(8, 'nguyen cao tri', 'nctri0110php@gmail.com', 'nnnnnnnnnn', 5, '2019-03-01 20:36:29', '2019-03-01 20:36:29'),
(9, 'nguyen cao tri', 'nctri0110php@gmail.com', 'fd', 1, '2019-03-04 00:47:33', '2019-03-04 00:47:33');

-- --------------------------------------------------------

--
-- Table structure for table `slide`
--

CREATE TABLE `slide` (
  `id` int(10) UNSIGNED NOT NULL,
  `image` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `slide`
--

INSERT INTO `slide` (`id`, `image`, `created_at`, `updated_at`) VALUES
(2, 'default1.jpg', NULL, NULL),
(3, 'default3.jpg', NULL, NULL),
(4, 'default4.jpg', NULL, NULL),
(5, 'default5.jpg', NULL, NULL),
(6, 'default6.jpg', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `full_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(11) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `privilege` int(10) NOT NULL COMMENT '0:user 1:admin',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `full_name`, `email`, `phone`, `address`, `email_verified_at`, `password`, `privilege`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'nguyen cao tri', 'nctri0110@gmail.com', '0334675630', 'biên hòa', NULL, '$2y$10$6OIGqfTXPdiyrooM8irtmuHHD15rovAbP0wYb0SS6eG5SSRGlk9ma', 1, NULL, NULL, NULL),
(2, 'nguyen cao tri', 'nguyenthihuong150998@gmail.com', '334567890', 'đong khoi, dsd', NULL, '$2y$10$Kf0cFksrdBhGEyhqNtQ7XeriCTSDsqhKIhyMNrRUtcXI9b8mF8ed.', 0, '29HJn7YUkH6U6EvDtaVi0mop8KzX6vbtfst6Y71QYxYvZ0R8RnI8WoM2J6zV', '2019-03-11 22:56:56', '2019-03-11 22:56:56'),
(3, 'nguyen cao tri', 'nguyenthihu@gmail.com', '334567890', 'đong khoi, dsd', NULL, '$2y$10$3qY.k4I8/6mTr3yYcXRgku0tzv87Yrad.DyNHXoATNza1ye2cINsW', 0, NULL, '2019-03-12 05:23:11', '2019-03-12 05:23:11'),
(4, 'nguyen cao tri', 'nguyenthihuong150998@gmail.co', '334567890', 'đong khoi, dsd', NULL, '$2y$10$Qxs18/8kk4tmYS4PScmz6.pAjNPoQk1qwEcfnD2uNzQHwNtDX.OXG', 0, NULL, '2019-03-12 05:23:57', '2019-03-12 05:23:57'),
(5, 'nguyen cao tri', 'nguyenthihuong150998@gmail.com0', '334567890', 'đong khoi, dsd', NULL, '$2y$10$S0v1U8x/rJ7j6rVBN20Bc.SMeIN/xRnGlnhbUPnupu6YaHH89I9S2', 0, NULL, '2019-03-12 06:39:30', '2019-03-12 06:39:30'),
(6, 'nguyen cao tri', 'nctri01102@gmail.cpom', '334567890', 'đong khoi, dsd', NULL, '$2y$10$GRLpl7zpbZUqkq5TbdhtB.XzVA3IteuA2P1ac1i//COKAEdTnD0aS', 0, NULL, '2019-03-12 06:41:09', '2019-03-12 06:41:09'),
(7, 'nguyen cao tri', 'nctri01102@gmail.com5', '334567890', 'đong khoi, dsd', NULL, '$2y$10$syZ6IwtOZf9.KDQoJT.rc.3ivLAvwDCFPzL143MrwKFLxoGxeWUbu', 0, NULL, '2019-03-12 06:41:38', '2019-03-12 06:41:38');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bill`
--
ALTER TABLE `bill`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bill_detail`
--
ALTER TABLE `bill_detail`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `email_registed`
--
ALTER TABLE `email_registed`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email_registed_email_unique` (`email`);

--
-- Indexes for table `introduce`
--
ALTER TABLE `introduce`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `policy`
--
ALTER TABLE `policy`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_image`
--
ALTER TABLE `product_image`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `recruitment`
--
ALTER TABLE `recruitment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `review`
--
ALTER TABLE `review`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `slide`
--
ALTER TABLE `slide`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bill`
--
ALTER TABLE `bill`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `bill_detail`
--
ALTER TABLE `bill_detail`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `email_registed`
--
ALTER TABLE `email_registed`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `introduce`
--
ALTER TABLE `introduce`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `policy`
--
ALTER TABLE `policy`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `product_image`
--
ALTER TABLE `product_image`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `recruitment`
--
ALTER TABLE `recruitment`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `review`
--
ALTER TABLE `review`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `slide`
--
ALTER TABLE `slide`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
