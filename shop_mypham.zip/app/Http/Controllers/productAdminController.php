<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\product;
use App\reviewModel;
use File;

class productAdminController extends Controller
{
     public function getproduct()
    {
    	$product=DB::table("product")->orderBy("id","desc")->get();
    	$cate=DB::table("category")->where("parent_ID","<>",0)->get();
    	// dd($cate);
    	return view("admin.product",compact("product","cate"));
    }

    public function postproduct(Request $re)
    {
    	// dd($re->all());
    	$re->validate([
		    'name' => 'required',
		    'description' => 'required',
		    'detail' => 'required',
		    'unit_price' => 'required|numeric',
		    'promotion_price' => 'required|numeric',
		    'quantity' => 'required|numeric',
		    'gender_use' => 'required|numeric|max:1|min:0',
		    'image' => 'required',
		],[
			'name.required' => 'Bạn chưa nhập tên sản phẩm!',
			'description.required' => 'Bạn chưa nhập mô tả ngắn!',
			'detail.required' => 'Bạn chưa nhập mô tả chi tiết!',
			'unit_price.required' => 'Bạn chưa nhập giá gốc!',
			'promotion_price.required' => 'Bạn chưa nhập giá mới!',
			'quantity.required' => 'Bạn nhập số lượng!',
			'gender_use.required' => 'Bạn chưa nhập giới tính sử dụng sản phẩm!',
			'image.required' => 'Bạn chưa chọn hình ảnh!',

			'quantity.numeric' => 'Số lượng phải là số!',
			'promotion_price.numeric' => 'Giá mới phải là số!',
			'unit_price.numeric' => 'Giá gốc phải là số!',
			'gender_use.numeric' => 'Giới tính phải là số từ 0-1!',
			'gender_use.max' => 'Chỉ được nhập 0 và 1!',
			'gender_use.min' => 'Chỉ được nhập 0 và 1!',
		]);

		$file=$re->file("image");
		$extension=["jpg","png","gif"];
		$flag=true;
		if($re->hasFile("image")){
				$name_extension=$file->getClientOriginalExtension();
				// echo $name_extension;
				$check=in_array($name_extension, $extension);
				if(!$check){
					$flag=false;
					return redirect()->route("getproduct")->with(["message"=>"File không đúng định dạng!","warning"=>"danger"]);
				}
		}

		if($flag){			
			if(isset($file)){
				$name_image=date("ymdhis").$file->getClientOriginalName();

				$ca=new product();
	    		$ca->name=$re->name;
	    		$ca->description=$re->description;
	    		$ca->detail=$re->detail;
	    		$ca->brand=$re->brand;

	    		$ca->unit_price=$re->unit_price;
	    		$ca->promotion_price=$re->promotion_price;
	    		$ca->image=$name_image;
	    		$ca->quantity=$re->quantity;
	    		$ca->category_ID=$re->category_ID;
	    		$ca->gender_use=$re->gender_use;
	    		$file->move("upload/product/",$name_image);
	    		$ca->save();
	    		return redirect()->route("getproduct")->with(["message"=>"Thêm thành công!","warning"=>"success"]);
			}
		}
    }

//del_ product
    public function delete_product($id)
	{
	    if($id){
	    	$pr=product::find($id);
	    	$pr->delete();
	    	$review=DB::table("review")->where("product_ID",$id)->get();
	    	// dd($review);
	    	if(count($review)>0){
	    		foreach ($review as $value) {
	    			$re=reviewModel::find($value->id);
	    			$re->delete();
	    		}
	    	}
	    	return redirect()->route("getproduct")->with(["message"=>"Xóa thành công","warning"=>"success"]);
	    }
	    else {
	    	return redirect()->route("getproduct")->with(["message"=>"Bạn xóa quá nhanh!Bạn chờ 3 giây rồi nhấn xóa lại nhé!","warning"=>"danger"]);
	    }
	}


	//show_product_cate
	public function show_product_cate(Request $re)
	{
		// dd($re->all());
		$parent_selected=$re->pro_cate_ID;
		$parent=DB::table("category")->where("parent_ID","<>",0)->get();
		return view("admin.edit_product_cate_ajax",compact("parent","parent_selected"));
	}

	//post edit product
	public function posteditproduct(Request $re)
	{
    	// dd($re->all());
    	$re->validate([
    		'edit_id' => 'required',
		    'edit_name' => 'required',
		    'edit_description' => 'required',
		    'edit_detail' => 'required',
		    'edit_unit_price' => 'required|numeric',
		    'edit_promotion_price' => 'required|numeric',
		    'edit_quantity' => 'required|numeric',
		    'edit_gender_use' => 'required|numeric|max:1|min:0',
		],[
			'edit_id.required' => 'Bạn sửa quá nhanh!chờ vài giây để trang kịp load bạn nhé!',
			'edit_name.required' => 'Bạn chưa nhập tên sản phẩm!',
			'edit_description.required' => 'Bạn chưa nhập mô tả ngắn!',
			'edit_detail.required' => 'Bạn chưa nhập mô tả chi tiết!',
			'edit_unit_price.required' => 'Bạn chưa nhập giá gốc!',
			'edit_promotion_price.required' => 'Bạn chưa nhập giá mới!',
			'edit_quantity.required' => 'Bạn nhập số lượng!',
			'edit_gender_use.required' => 'Bạn chưa nhập giới tính sử dụng sản phẩm!',

			'edit_quantity.numeric' => 'Số lượng phải là số!',
			'edit_promotion_price.numeric' => 'Giá mới phải là số!',
			'edit_unit_price.numeric' => 'Giá gốc phải là số!',
			'edit_gender_use.numeric' => 'Giới tính phải là số từ 0-1!',
			'edit_gender_use.max' => 'Chỉ được nhập 0 và 1!',
			'edit_gender_use.min' => 'Chỉ được nhập 0 và 1!',
		]);

		$file=$re->file("img_new");
		$extension=["jpg","png","gif"];
		$flag=true;
		if($re->hasFile("img_new")){
				// echo "has";
				$name_extension=$file->getClientOriginalExtension();
				// echo $name_extension;
				$check=in_array($name_extension, $extension);
				if(!$check){
					$flag=false;
					return redirect()->route("getproduct")->with(["message"=>"File không đúng định dạng!","warning"=>"danger"]);
				}
		}

		if($flag){			
			if(isset($file)){
				$name_image=date("ymdhis").$file->getClientOriginalName();
				// echo $name_image;
				$pro=product::find($re->edit_id);
	    		$pro->name=$re->edit_name;
	    		$pro->description=$re->edit_description;
	    		$pro->detail=$re->edit_detail;
	    		$pro->brand=$re->edit_brand;

	    		$pro->unit_price=$re->edit_unit_price;
	    		$pro->promotion_price=$re->edit_promotion_price;
	    		$pro->image=$name_image;
	    		$pro->quantity=$re->edit_quantity;
	    		$pro->category_ID=$re->edit_category_ID;
	    		$pro->gender_use=$re->edit_gender_use;
				$file->move("upload/product/",$name_image);
				$url_old="upload/product/".$re->image_hidden;
				// echo $url_old;
				if(File::exists($url_old)){
					if(File::delete($url_old));
				}
				$pro->save();
				return redirect()->route("getproduct")->with(["message"=>"Sửa thành công!","warning"=>"success"]);
			}
			else{
				$pro=product::find($re->edit_id);
	    		$pro->name=$re->edit_name;
	    		$pro->description=$re->edit_description;
	    		$pro->detail=$re->edit_detail;
	    		$pro->brand=$re->edit_brand;

	    		$pro->unit_price=$re->edit_unit_price;
	    		$pro->promotion_price=$re->edit_promotion_price;
	    		$pro->quantity=$re->edit_quantity;
	    		$pro->category_ID=$re->edit_category_ID;
	    		$pro->gender_use=$re->edit_gender_use;
				$pro->save();
				return redirect()->route("getproduct")->with(["message"=>"Sửa thành công!","warning"=>"success"]);
			}
			
		}
		
	}

}
