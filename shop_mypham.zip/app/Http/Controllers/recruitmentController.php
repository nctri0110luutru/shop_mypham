<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\recruitment;

class recruitmentController extends Controller
{
    public function getrecruitment()
    {
    	$recruitment=DB::table("recruitment")->orderBy("id","desc")->get();
    	$mottin=DB::table("recruitment")->orderBy("id","desc")->first();
    	$id=$mottin->id;
    	return view("admin.recruitment",compact("recruitment","id"));
    }

    public function postrecruitment(Request $re)
    {
    	// dd($re->all());
    	$re->validate([
		    'add_recruitment' => 'required'
		],[
			'add_recruitment.required' => 'Bạn chưa nhập thông tin!'
		]);

    	if($re->add_recruitment){
    		$r=new recruitment();
    		$r->recruitment_detail=$re->add_recruitment;
    		$r->save();
    		return redirect()->route("getrecruitment")->with(["message"=>"Thêm thành công","warning"=>"success"]);
    	}
    	else{
    		return redirect()->route("getrecruitment")->with(["message"=>"Đã xảy ra lỗi!","warning"=>"danger"]);
    	}

    }

	public function delete_recruitment($id)
	{
	    if($id){
	    	$del=recruitment::find($id);
	    	$del->delete();
	    	return redirect()->route("getrecruitment")->with(["message"=>"Xóa thành công","warning"=>"success"]);
	    }
	    else{
	    	return redirect()->route("getrecruitment")->with(["message"=>"Đã xảy ra lỗi!","warning"=>"danger"]);
	    }
	}

	//edit
	public function posteditrecruitment(Request $re)
    {
    	// dd($re->all());
    	$re->validate([
		    'edit_id_recruitment' => 'required',
		    'edit_recruitment_detail' => 'required',
		],[
			'edit_id_recruitment.required' => 'Bạn chưa nhập thông tin!',
			'edit_recruitment_detail.required' => 'Bạn chưa nhập thông tin!'
		]);
    	$edit_rec=recruitment::find($re->edit_id_recruitment);
    	if($edit_rec){
    		$edit_rec->recruitment_detail=$re->edit_recruitment_detail;
    		$edit_rec->save();
    		return redirect()->route("getrecruitment")->with(["message"=>"Sửa thành công","warning"=>"success"]);
    	}
    	else{
    		return redirect()->route("getrecruitment")->with(["message"=>"Đã xảy ra lỗi!","warning"=>"danger"]);
    	}

    }

}
