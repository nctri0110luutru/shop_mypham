<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class emailregisted extends Model
{
     protected $table = "email_registed";
     protected $fillable = [
         'email',
    ];
}
