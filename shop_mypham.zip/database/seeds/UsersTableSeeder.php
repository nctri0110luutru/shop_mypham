<?php

use Illuminate\Database\Seeder;

class UsersTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        DB::table('users')->insert([
            
            'full_name'=>"nguyen cao tri",
            'email' => 'nctri0110luutru@gmail.com',
            'phone'=>'0334675630',
            'address'=>'biên hòa',
            'password' => bcrypt('123456'),
            'privilege'=>0,
        ]);
    }
}
