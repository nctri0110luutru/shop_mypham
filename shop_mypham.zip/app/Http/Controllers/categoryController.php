<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\category;
use App\product;
class categoryController extends Controller
{
    public function getcategory()
    {
    	$category=DB::table("category")->orderBy("id","desc")->get();
    	$parent_cate=DB::table("category")->where("parent_ID",0)->get();
    	return view("admin.category",compact("category","parent_cate"));
    }

    public function postcategory(Request $re)
    {
    	// dd($re->all());
    	$re->validate([
		    'name' => 'required',
		    'parent' => 'required',
		],[
			'name.required' => 'Bạn chưa nhập tên danh mục!',
			'parent.required' => 'Bạn chưa chọn danh mục cha!',
		]);

    	if($re->name){
    		$ca=new category();
    		$ca->name=$re->name;
    		$ca->parent_ID=$re->parent;
    		$ca->save();
    		return redirect()->route("getcategory")->with(["message"=>"Thêm thành công","warning"=>"success"]);
    	}
    	else{
    		return redirect()->route("getcategory")->with(["message"=>"Đã xảy ra lỗi!","warning"=>"danger"]);
    	}

    }


    public function delete_category($id,$parent)
	{
	    if($id){
	    	$del_parent=category::find($id);
	    	$child=category::where("parent_ID",$id)->get();
	    	// dd($del_child);
	    	if($parent!=0){
	    		
	    		$product=product::where("category_ID",$id)->get();
	    		if(count($product)>0){
	    			foreach ($product as $value) {
	    				$del_pro=product::find($value->id);
	    				$del_pro->delete();
	    			}
	    		}
	    		$del_parent->delete();
	    		return redirect()->route("getcategory")->with(["message"=>"Xóa thành công","warning"=>"success"]);
	    	}
	    	else{
	    		foreach ($child as $value) {
	    			$id_child=$value->id;
	    			$product=product::where("category_ID",$id_child)->get();
	    			foreach ($product as $value) {
	    				$del_pro=product::find($value->id);
	    				$del_pro->delete();
	    			}
	    			$del_child=category::find($id_child);
	    			$del_child->delete();
	    		}
	    		$del_parent->delete();
	    		return redirect()->route("getcategory")->with(["message"=>"Xóa thành công tất cả dữ liệu (danh mục và sản phẩm) liên quan","warning"=>"success"]);
	    	}
	    	
	    }
	    else{
	    	return redirect()->route("getcategory")->with(["message"=>"Xóa thất bại!","warning"=>"danger"]);
	    }
	}

	//show_category_edit
	public function show_category_parent(Request $re)
	{
		$parent_selected=$re->ca_parent;
		$parent=DB::table("category")->where("parent_ID",0)->get();
		return view("admin.edit_ajax_category",compact("parent","parent_selected"));
	}

	public function posteditcategory(Request $re)
	{
		// dd($re->all());
		$re->validate([
		    'edit_name_category' => 'required',
		    'edit_id_category' => 'required',

		],[
			'edit_name_category.required' => 'Bạn chưa nhập tên danh mục!',
			'edit_id_category.required' => 'Bạn chờ 3 giây để trang kịp cập nhật nhé!',
		]);
		if($re->edit_id_category){
    		$ca=category::find($re->edit_id_category);
    		$ca->name=$re->edit_name_category;
    		if($re->parent){
    			$ca->parent_ID=$re->parent;
    		}
    		$ca->save();
    		return redirect()->route("getcategory")->with(["message"=>"Sửa thành công","warning"=>"success"]);
    	}
    	else{
    		return redirect()->route("getcategory")->with(["message"=>"Đã xảy ra lỗi!","warning"=>"danger"]);
    	}
	}
}
