<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use File;
use App\slide;

class slideController extends Controller
{
   public function getslide()
   {
   		$slide=DB::table("slide")->orderBy("id","desc")->get();
   		
   		return view('admin.slide',compact("slide"));
   }

   public function postslide(Request $re)
   {
   		// $slide=DB::table("slide")->orderBy("id","desc")->get();
   		// return view('admin.slide',compact("slide"));
   		$re->validate([
		    'fImages' => 'required'
		],[
			'fImages.required' => 'Bạn chưa chọn file!'
		]);

		$file_arr=$re->file("fImages");
		$extension=["jpg","png","gif"];
		$flag=true;
		if($re->hasFile("fImages")){
			foreach ($file_arr as $value) {
				$name_extension=$value->getClientOriginalExtension();
				$check=in_array($name_extension, $extension);
				if(!$check){
					$flag=false;
					return redirect()->route("getslide")->with(["message"=>"File không đúng định dạng!","warning"=>"danger"]);
				}
			}
		}

		if($flag){
			foreach ($file_arr as $value) {
				if(isset($value)){
					$name_image=date("ymdhis").$value->getClientOriginalName();
					$s=new slide();
					$s->image=$name_image;
					$v=$value->move("upload/slide/",$name_image);
					$s->save();
				}
			}
			return redirect()->route("getslide")->with(["message"=>"Thêm thành công!","warning"=>"success"]);
		}
		
   }

   public function delete_slide($id)
   {
   		if($id){
   			$del=slide::find($id);
   			if(!empty($del)){
   				$url="upload/slide/".$del->image;
   				if(File::exists($url)){
   					File::delete($url);
   				}
   				$del->delete();
    			return redirect()->route("getslide")->with(["message"=>"Xóa thành công!","warning"=>"success"]);
   			}
   		}
   }
}
