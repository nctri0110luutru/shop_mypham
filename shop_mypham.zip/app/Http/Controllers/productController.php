<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB,Session;
use App\reviewModel;
class productController extends Controller
{
	//productloadajax
	public function getProductLoadAjax(Request $re)
	{
				if($_GET["opt"]=="default"){
    				$product= DB::table("product")->get();
                    
    				// return redirect("product",compact("product"));
    			}
    			if($_GET["opt"]=="des-asc"){
    				$product= DB::table("product")->orderBy('unit_price','asc')->get();
                    // $product->appends(['opt' => $re->opt]);
    			}
    			if($_GET["opt"]=="asc-des"){
    				$product= DB::table("product")->orderBy('unit_price','desc')->get();
    				// $product->appends(['opt' => $re->opt]);
    			}
    			if($_GET["opt"]=="a-z"){
    				$product= DB::table("product")->orderBy('name','asc')->get();
    				// $product->appends(['opt' => $re->opt]);
    			}
    			if($_GET["opt"]=="z-a"){
    				$product= DB::table("product")->orderBy('name','desc')->get();
    		          // $product->appends(['opt' => $re->opt]);

    			}
    			return view("client.loadajax",compact("product"));
	}


	//left search product
    public function getProduct(Request $re)
    {
    	if($re->has("search")){
    		$product= DB::table("product")->where('name',"like","%".$re->search."%")->orWhere("unit_price",$re->search)->paginate(3);
            $product->appends(['search' => $re->search]);
    		// dd($product);
    	}
    	else if($re->has("type")){
    		if($re->type=="nu"){
    			$product= DB::table("product")->where('gender_use',0)->paginate(3);
                $product->appends(['type' => $re->type]);
    		}
    		else if($re->type=="nam"){
    			$product= DB::table("product")->where('gender_use',1)->paginate(3);
                $product->appends(['type' => $re->type]);
    		}
    		else if($re->type=="sale"){
    			$product= DB::table("product")->where("promotion_price","<>",0)->paginate(3);
                $product->appends(['type' => $re->type]);
    		}

    		//price
    		else if($re->type=="smaller100"){
    			$product= DB::table("product")->where('unit_price',"<",100000)->paginate(3);
                $product->appends(['type' => $re->type]);
    		}
    		else if($re->type=="between100to300"){
    			$product= DB::table("product")->whereBetween('unit_price', [100000, 300000])->paginate(3);
                $product->appends(['type' => $re->type]);
    		}
    		else if($re->type=="between300to500"){
    			$product= DB::table("product")->whereBetween('unit_price', [300000, 500000])->paginate(3);
                $product->appends(['type' => $re->type]);
    		}
    		else if($re->type=="between500to1000"){
    			$product= DB::table("product")->whereBetween('unit_price', [500000, 1000000])->paginate(3);
                $product->appends(['type' => $re->type]);
    		}
    		else if($re->type=="bigger1000"){
    			$product= DB::table("product")->where("unit_price",">",1000000)->paginate(3);
                $product->appends(['type' => $re->type]);
    		}
    		//end price
    		else{
    			return redirect("/");
    		}

    	}
    	else if($re->has("product")){
    		$product= DB::table("product")->where('category_ID',$re->product)->paginate(2);
            $product->appends(['product' => $re->product]);
    	}
    	else{
    		$product= DB::table("product")->orderBy("id","desc")->paginate(3);
    	}
    	$category= DB::select("CALL sp_select_all_category()");

    	// $product= DB::table("product")->paginate(3);
    	$product_sale=DB::table("product")->where("promotion_price","<>",0)->orderBy("id","desc")->take(5)->get();
    	// // dd($category);
    	return view('client.product',compact("category","product","product_sale"));
    }





    //product detail
    public function getProductDetail($id)
    {
        $idpro=$id;
        $productdetail= DB::table("product")->where("id",$id)->first();
        $relatedproduct= DB::table("product")->where("category_ID",$productdetail->category_ID)->get();
        // dd($relatedproduct);
    	return view("client.productdetail",compact("productdetail","relatedproduct","idpro"));
    }

    //load review

    public function getLoadReview($id)
    {
        
        Session::put("idreview",$id);
        $review=DB::table("review")->where("product_ID",$id)->orderBy("id","desc")->get();
        return view("client.reviewajax",compact("review"));
    }
    
    public function postLoadReview(Request $re)
    {
       $validatedData = $re->validate([
            'name' => 'required|max:255',
            'email' => 'required|email',
            'review'=>"required|max:255"
        ]);
        $v=Session::get("idreview");

        // // // echo Session::get("id");
        // // $review=DB::table("review")->where("product_ID",$id)->orderBy("id","desc")->get();
        // // return view("client.reviewajax",compact("review"));
        // dd($re->all());
        if($re->Session()){
            $reviewtb= new reviewModel();
            $reviewtb->customer_name= $re->name;
            $reviewtb->customer_email= $re->email;
            $reviewtb->message= $re->review;
            $reviewtb->product_ID= $v;
            $reviewtb->save();
        }
        return redirect()->back()->with(["reviewSuccess"=>"ok"]); 
        
    }
    
}
