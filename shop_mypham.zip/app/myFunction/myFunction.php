			<?php
				public function getModel($gtri)
				{

			?>
					
				
				<!-- Modal -->
							  <div class="modal fade" id="myModal{{$gtri->id}}" role="dialog">
							    <div class="modal-dialog">
							    
							      <!-- Modal content-->
							      <div class="modal-content" style="background-color: #F5A9E1">
							        <div class="modal-header">
							          <button type="button" class="close" data-dismiss="modal">&times;</button>
							          <h4 class="modal-title"><i class="fa fa-truck" aria-hidden="true"></i>   {{$gtri->name}}</h4>
							      
										<p><strong>Giới thiệu:</strong> {{$gtri->description}}.</p>
										
							        </div>
							        <div class="modal-body" >
							        	<img id="hinh" src="{{asset('upload/product/'.$gtri->image)}}" style="width: 100%; height: 250px;" alt="">
							     	<div class="row" style="padding-top: 8px;">
							          <div class="product-btns col-md-6">
											<button class="main-btn icon-btn"><i class="fa fa-heart"></i></button>
											<button class="main-btn icon-btn"><i class="fa fa-exchange"></i></button>
											<button class="primary-btn add-to-cart"><i class="fa fa-shopping-cart"></i> Add to Cart</button>
										</div>
										<div class="product-rating col-md-6" style="text-align: right;">
											<i class="fa fa-star"></i>
											<i class="fa fa-star"></i>
											<i class="fa fa-star"></i>
											<i class="fa fa-star"></i>
											<i class="fa fa-star-o empty"></i>
										</div>
									</div>
							        </div>
							        <div class="modal-footer">
							          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
							        </div>
							      </div>
							      
							    </div>
							  </div>
				<!-- endmodal -->
<?php
	}
?>