<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\User;
use Hash;

class userController extends Controller
{
    public function getuser()
    {
    	$user=DB::table("Users")->get();
    	return view("admin.user",compact("user"));
    }

    public function delete_user($id)
    {
    	if($id){
    		$u=User::find($id);
    		$u->delete();
    		return redirect()->route("getuser")->with(["message"=>"Xóa thành công","warning"=>"success"]);

    	}
    	else{
    		return redirect()->route("getuser")->with(["message"=>"Đã xảy ra lỗi","warning"=>"danger"]);
    	}
    }

    //edit admin
    public function edit_admin()
    {
    	$admin=DB::table("Users")->where("privilege",1)->first();
    	return view("admin.user_admin",compact("admin"));
    }

    //post edit admin
    public function post_edit_admin(Request $re,$id)
    {
    	// dd($re->all());
    	$admin=DB::table("Users")->where("privilege",1)->first();
    	$validatedData = $re->validate([
	        'full_name' => 'required',
	        'phone' => 'required|max:12',
	        'address' => 'required',
	        'pass_old'=>'required|min:6|max:32',
	        'pass_new'=>'required|min:6|max:32|same:has_pass',
   		],[
   			'full_name.required' => 'Bạn phải nhập tên!',
	        'email.required' => 'Bạn phải nhập email!',
	        'email.email' => 'Email chưa đúng định dạng!',
	        'email.unique' => 'Có người khác đã sử dụng email này!',
	        'phone.required' => 'Bạn phải nhập SĐT!',
	        'address.required' => 'Bạn phải nhập địa chỉ!',

	        'pass_old.required' => 'Bạn phải nhập mật khẩu cũ!',
	        'pass_old.min' => 'Bạn phải nhập mật khẩu >6 và <32 kí tự!',
	        'pass_old.max' => 'Bạn phải nhập mật khẩu >6 và <32 kí tự!',

	        'pass_new.required' => 'Bạn chưa nhập mật khẩu mới!',
	        'pass_new.min' => 'Bạn phải nhập mật khẩu >6 và <32 kí tự!',
	        'pass_new.max' => 'Bạn phải nhập mật khẩu >6 và <32 kí tự!',
	        'pass_new.same' => 'Hai mật khẩu bản nhập không trùng khớp!',
	        
   		]);
   		if(Hash::check($re->pass_old, $admin->password)){
   			$u=User::find($id);
	    	$u->full_name=$re->full_name;
	    	$u->email=$admin->email;
	    	$u->phone=$re->phone;
	    	$u->address=$re->address;
	    	$u->password=bcrypt($re->pass_new);
	    	$u->privilege=1;
	    	$u->save();
	    	return redirect()->route("edit_admin")->with(["message"=>"Cập nhật thành công bạn có thể sử dụng mật khẩu mới","warning"=>"success"]);
   		}
   		else{
   			return redirect()->route("edit_admin")->with(["message"=>"Mật khẩu cũ của bạn nhập không đúng!","warning"=>"success"]);
   		}
    	
    }
}
