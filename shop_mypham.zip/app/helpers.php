<?php
//load model html
if (! function_exists('getModel')) {
	function getModel($arr)
	{
		foreach ($arr as $value) {
				# code...
			

			?>
			<!-- Modal -->
			<!-- Product Single -->
			
			<div class="col-md-3 col-sm-6 col-xs-6">
				<div class="product product-single">
					<div class="product-thumb">
						<?php
						if($value->promotion_price!=0){
							?>
							<div class="product-label">
								<span class="sale">sale</span>
							</div>
							<?php
						}
						?>
						<?php echo '<button id="myquickview" value="'.$value->id.'" class="main-btn quick-view"><i class="fa fa-search-plus"></i> Quick view</button>
						<img src="../public/upload/product/'.$value->image.'" style="width: 100%; height: 263px;" alt="">';?>
					</div>
					<div class="product-body">
						<?php
						if($value->promotion_price!=0){
							echo '<h3 class="product-price">'.number_format($value->promotion_price,0,"",".").'<sup><span style="color: orange;">đ</span></sup><del class="product-old-price">'.number_format($value->unit_price,0,"",".").'<sup><span style="color: orange;">đ</span></sup></del></h3>';
						}
						else{
							echo '<h3 class="product-price">'.number_format($value->unit_price,0,"",".").'<sup><span style="color: orange;">đ</span></sup></h3>';
						}							
						?>
						<!-- <div class="product-rating">
							<i class="fa fa-star"></i>
							<i class="fa fa-star"></i>
							<i class="fa fa-star"></i>
							<i class="fa fa-star"></i>
							<i class="fa fa-star-o empty"></i>
						</div> -->
						
						<?php echo '<h2 class="product-name"><a href="../public/productdetail/'.$value->id.'" title="Xem chi tiết">'.$value->name.'</a></h2>'?>
						
						<div class="product-btns">
							<!-- <button class="main-btn icon-btn"><i class="fa fa-heart"></i></button>
								<button class="main-btn icon-btn"><i class="fa fa-exchange"></i></button> -->
								<?php if($value->quantity>0) echo '<a href="../public/shoppingCart/'.$value->id.'"><button class="primary-btn add-to-cart"><i class="fa fa-shopping-cart"></i> Add to Cart</button></a>'; else echo '<button class="primary-btn add-to-cart"><i class="fa fa-shopping-cart"></i> Hết hàng!</button></a>';?>
							</div>
						</div>
					</div>
				</div>
				<!-- /Product Single -->
				<!-- Modal -->
				<?php
				echo '<div class="modal fade" id="myModal'.$value->id.'" role="dialog">';
				?>
				<div class="modal-dialog">

					<!-- Modal content-->
					<div class="modal-content" style="background-color: #F5A9E1">
						<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal">&times;</button>
							<h4 class="modal-title"><i class="fa fa-truck" aria-hidden="true"></i>   <?php echo $value->name;?></h4>

							<p><strong>Giới thiệu:</strong> <?php echo $value->description;?>.</p>

						</div>
						<div class="modal-body" >
							<?php
							echo '<img id="hinh" src="../public/upload/product/'.$value->image.'" style="width: 100%; height: 250px;" alt="">';
							?>
							<div class="row" style="padding-top: 8px;">
								<div class="product-btns col-md-6">
								<!-- <button class="main-btn icon-btn"><i class="fa fa-heart"></i></button>
									<button class="main-btn icon-btn"><i class="fa fa-exchange"></i></button> -->
									<?php if($value->quantity>0) echo '<a href="../public/shoppingCart/'.$value->id.'"><button class="primary-btn add-to-cart"><i class="fa fa-shopping-cart"></i> Add to Cart</button></a>'; else echo '<button class="primary-btn add-to-cart"><i class="fa fa-shopping-cart"></i> Hết hàng!</button></a>';?>
								</div>
								<div class="product-rating col-md-6" style="text-align: right;">
									<i class="fa fa-star"></i>
									<i class="fa fa-star"></i>
									<i class="fa fa-star"></i>
									<i class="fa fa-star"></i>
									<i class="fa fa-star-o empty"></i>
								</div>
							</div>
						</div>
						<div class="modal-footer">
							<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
						</div>
					</div>

				</div>
			</div>
			<!-- endmodal -->
<?php
		}
	}

}

?>

<?php
	//parent_ category
	if (! function_exists('parent_category')) {
	    function parent_category($parent) {
	    	if($parent!=0){//kiem tra xem no có dư liệu k....vì khi parent=0 sẻ k select dk name nên phải loại trường hợp này đi
		        $data=DB::table("category")->where("id",$parent)->select("name")->first();
		        if(isset($data))
		        {
		        		echo $data->name;
		        }
			}
	    }
	}



	//category_parent of product
	if (! function_exists('cate_parent_product')) {
	    function cate_parent_product($parent) {
	    	$data=DB::table("category")->where("id",$parent)->select("name")->first();
	    	echo $data->name;
	    }
	}

?>